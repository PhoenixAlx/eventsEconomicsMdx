# eventsEconomicsMdx
Plugin to show events on a wordpress' page

## Instructions:

1. Install plugins
2. Active plugins
3. Make a new page.
4. Insert short code [events  category="events" limit="50" length_title="100000" ]
5. Make some post and you put it on a category , for example events.

Options:

* category= name of category of your events' post 
* limit= number of posts to show
* length_title= number of character of title to show
